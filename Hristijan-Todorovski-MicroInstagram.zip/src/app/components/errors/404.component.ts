import { Component } from "@angular/core";

@Component({
  template:`
  <h1>404'd</h1>
  `
})
export class Error404Component{

}
